import XCTest
@testable import LittleLemonDinnerMenu

@MainActor final class CapstoneTests: XCTestCase {
    func testRegistrationProfileEditsSurviveRestartAndLogoutClearsData() throws {
        let suite = "capstone-tests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = ProfileStore(defaults: defaults)
        XCTAssertNil(store.profile)
        var profile = UserProfile(firstName: " Ada ", lastName: "Lovelace", email: "ada@example.com", phone: "123")
        try store.save(profile)
        let restarted = ProfileStore(defaults: defaults)
        XCTAssertEqual(restarted.profile?.firstName, "Ada")
        profile.firstName = "Grace"
        try restarted.save(profile)
        XCTAssertEqual(ProfileStore(defaults: defaults).profile?.firstName, "Grace")
        restarted.logOut()
        XCTAssertNil(ProfileStore(defaults: defaults).profile)
        XCTAssertNil(defaults.data(forKey: "littleLemon.capstone.profile"))
    }
    func testInvalidRegistrationDoesNotPersistProfile() throws {
        let suite = "capstone-tests-\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = ProfileStore(defaults: defaults)
        XCTAssertThrowsError(try store.save(UserProfile(firstName: "Ada", lastName: "", email: "not-an-email")))
        XCTAssertNil(store.profile)
    }
    func testMenuCacheDeduplicatesAndPersistsFields() throws {
        let cache = try MenuCache(inMemory: true)
        let dish = FoodItem(id: 1, title: "Crème Soup", description: "Soup", price: "12", image: "https://example.com/soup.jpg", category: "starters")
        try cache.replace(with: [dish, dish])
        XCTAssertEqual(try cache.fetch(), [dish])
        try cache.replace(with: [dish])
        XCTAssertEqual(try cache.fetch().count, 1)
        XCTAssertEqual(MenuStore.filter([dish], search: "CREME", category: .starters), [dish])
        XCTAssertTrue(MenuStore.filter([dish], search: "", category: .desserts).isEmpty)
    }
}
