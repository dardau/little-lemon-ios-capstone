# Verification — November 8, 2026

- Xcode 27.2: generic iOS Simulator build succeeded.
- XCTest on iPhone 18 Pro / iOS 27.2: 3 tests passed, 0 failures.
- Native simulator UI inspected and operated through Device Hub:
  - onboarding advances from page 1 to 2 to 3;
  - empty email shows a correction message and preserves entered names;
  - summary shows the test name/email/phone and Register opens Home;
  - Home shows header, restaurant hero/search, category bar and dish list;
  - GREEK finds Greek Salad; Clear search restores the menu;
  - Desserts selects Lemon Desert; dish details and Back navigation work;
  - Profile contains the data entered during onboarding;
  - changing Ada to Grace and saving shows Profile saved;
  - the app was stopped in Xcode and run again; Profile still showed Grace;
  - Log out asks for confirmation; confirming returns to page 1 with blank names.
- Test inputs were fictional (Ada/Grace Lovelace, ada@example.com).
- Native screenshots: onboarding-3.png, home-menu.png, search-greek.png,
  profile-saved.png, profile-after-restart.png.
- Static premium UI audit: 0 errors/warnings. DESIGN.md lint: 0 errors;
  3 informational orphan-token warnings for colors owned by native SwiftUI.

Not claimed: Figma export, App Store publishing, real orders/payments, an online
user account, exhaustive accessibility certification or offline-device testing.
The wireframe was authored locally as editable SVG and JPG.
