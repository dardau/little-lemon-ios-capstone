"""Create an editable grayscale Home wireframe and the required JPG artifact."""
from pathlib import Path
from html import escape
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
image = Image.new('RGB', (1000, 1320), 'white')
draw = ImageDraw.Draw(image)
svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="1320" viewBox="0 0 1000 1320" role="img" aria-label="Little Lemon Home screen wireframe">', '<rect width="1000" height="1320" fill="white"/>']
font_path = '/System/Library/Fonts/Supplemental/Arial.ttf'


def text(x, y, content, size=24, color='#333333'):
    draw.text((x,y),content,font=ImageFont.truetype(font_path,size),fill=color)
    svg.append(f'<text x="{x}" y="{y+size}" font-family="Arial,sans-serif" font-size="{size}" fill="{color}">{escape(content)}</text>')


def rect(x,y,w,h,fill='white',stroke='#666666',radius=0):
    draw.rounded_rectangle((x,y,x+w,y+h),radius=radius,fill=fill,outline=stroke,width=2)
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')


def line(x1,y1,x2,y2):
    draw.line((x1,y1,x2,y2),fill='#999999',width=2)
    svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#999999" stroke-width="2"/>')


text(60,20,'Little Lemon — Home wireframe',32)
rect(60,80,600,1160,radius=30)
rect(90,115,540,95)
text(110,145,'Little Lemon / logo',29)
rect(558,132,52,52,fill='#E8E8E8',radius=26)
text(565,145,'AB',19)
text(720,145,'Header',26)
line(640,165,700,165)

rect(90,210,540,300,fill='#E8E8E8')
text(115,235,'Little Lemon',36)
text(115,282,'Chicago',26)
text(115,328,'Restaurant description',23)
text(115,362,'Mediterranean dishes, family recipes',21)
rect(115,420,490,62,radius=10)
text(137,437,'Search dishes',23)
text(720,315,'Hero + search',26)
line(640,350,700,350)

text(110,542,'ORDER FOR DELIVERY',23)
for x,caption,width in [(110,'All',65),(185,'Starters',108),(303,'Mains',94),(407,'Desserts',118),(535,'Drinks',82)]:
    rect(x,582,width,45,fill='#E8E8E8',radius=20)
    text(x+10,592,caption,18)
text(720,568,'Menu breakdown',25)
line(640,605,700,605)

for y,caption in [(672,'Greek Salad'),(842,'Bruschetta'),(1012,'Lemon Dessert')]:
    text(112,y,caption,27)
    text(112,y+45,'Short description of the dish',21)
    text(112,y+86,'$ price',23)
    rect(512,y,95,100,fill='#EEEEEE',radius=10)
    line(520,y+8,599,y+92)
    line(599,y+8,520,y+92)
    line(110,y+140,610,y+140)
text(720,834,'Food menu list',25)
text(720,873,'Title · description',20)
text(720,904,'Price · image',20)
line(640,880,700,880)
text(80,1265,'Flow: Onboarding (3 pages) → Home → Profile / Dish details → Back',21)
svg.append('</svg>')
(ROOT/'wireframe-home.svg').write_text('\n'.join(svg))
image.save(ROOT/'wireframe-home.jpg',quality=95)
print('Created wireframe-home.svg and wireframe-home.jpg')
