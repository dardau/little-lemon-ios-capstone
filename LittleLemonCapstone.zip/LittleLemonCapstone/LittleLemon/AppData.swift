import SwiftUI
import CoreData

struct UserProfile: Codable, Equatable {
    var firstName = ""
    var lastName = ""
    var email = ""
    var phone = ""

    var initials: String { String(firstName.prefix(1) + lastName.prefix(1)).uppercased() }
    var nameIsValid: Bool { !firstName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !lastName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var emailIsValid: Bool {
        let parts = email.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: "@", omittingEmptySubsequences: false)
        return parts.count == 2 && !parts[0].isEmpty && parts[1].contains(".") && !parts[1].hasPrefix(".") && !parts[1].hasSuffix(".") && !email.contains(where: \.isWhitespace)
    }
    var validationError: String? {
        if !nameIsValid { return "Enter your first and last name." }
        if !emailIsValid { return "Enter an email address such as name@example.com." }
        return nil
    }
    var cleaned: UserProfile {
        UserProfile(firstName: firstName.trimmingCharacters(in: .whitespacesAndNewlines), lastName: lastName.trimmingCharacters(in: .whitespacesAndNewlines), email: email.trimmingCharacters(in: .whitespacesAndNewlines), phone: phone.trimmingCharacters(in: .whitespacesAndNewlines))
    }
}

@MainActor final class ProfileStore: ObservableObject {
    @Published private(set) var profile: UserProfile?
    private let defaults: UserDefaults
    private let key = "littleLemon.capstone.profile"
    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: key) {
            profile = try? JSONDecoder().decode(UserProfile.self, from: data)
        }
    }
    func save(_ value: UserProfile) throws {
        let clean = value.cleaned
        guard clean.validationError == nil else { throw ProfileError.invalid }
        let data = try JSONEncoder().encode(clean)
        defaults.set(data, forKey: key)
        profile = clean
    }
    func logOut() {
        defaults.removeObject(forKey: key)
        profile = nil
    }
    enum ProfileError: Error { case invalid }
}

struct MenuEnvelope: Decodable { let menu: [FoodItem] }
struct FoodItem: Codable, Identifiable, Equatable {
    let id: Int
    let title: String
    let description: String
    let price: String
    let image: String
    let category: String
    var numericPrice: Double { Double(price) ?? 0 }
}

enum FoodCategory: String, CaseIterable, Identifiable {
    case all = "All", starters = "Starters", mains = "Mains", desserts = "Desserts", drinks = "Drinks"
    var id: String { rawValue }
    var serverName: String { rawValue.lowercased() }
}

@MainActor final class MenuCache {
    let container: NSPersistentContainer
    init(inMemory: Bool = false) throws {
        let model = NSManagedObjectModel()
        let entity = NSEntityDescription()
        entity.name = "CachedDish"
        entity.managedObjectClassName = "NSManagedObject"
        let fields: [(String, NSAttributeType)] = [("id", .integer64AttributeType), ("title", .stringAttributeType), ("dishDescription", .stringAttributeType), ("price", .stringAttributeType), ("image", .stringAttributeType), ("category", .stringAttributeType)]
        entity.properties = fields.map { name, type in
            let attribute = NSAttributeDescription()
            attribute.name = name
            attribute.attributeType = type
            attribute.isOptional = false
            return attribute
        }
        entity.uniquenessConstraints = [["id"]]
        model.entities = [entity]
        container = NSPersistentContainer(name: "CapstoneMenu", managedObjectModel: model)
        let store = NSPersistentStoreDescription()
        if inMemory {
            store.type = NSInMemoryStoreType
        } else {
            let directory = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("LittleLemonCapstone", isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            store.url = directory.appendingPathComponent("menu.sqlite")
        }
        store.shouldAddStoreAsynchronously = false
        container.persistentStoreDescriptions = [store]
        var failure: Error?
        container.loadPersistentStores { _, error in failure = error }
        if let failure { throw failure }
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }
    func fetch() throws -> [FoodItem] {
        let request = NSFetchRequest<NSManagedObject>(entityName: "CachedDish")
        request.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))]
        return try container.viewContext.fetch(request).compactMap { row in
            guard let title = row.value(forKey: "title") as? String,
                  let description = row.value(forKey: "dishDescription") as? String,
                  let price = row.value(forKey: "price") as? String,
                  let image = row.value(forKey: "image") as? String,
                  let category = row.value(forKey: "category") as? String else { return nil }
            return FoodItem(id: (row.value(forKey: "id") as? NSNumber)?.intValue ?? 0, title: title, description: description, price: price, image: image, category: category)
        }
    }
    func replace(with dishes: [FoodItem]) throws {
        let context = container.viewContext
        do {
            let request = NSFetchRequest<NSManagedObject>(entityName: "CachedDish")
            for row in try context.fetch(request) { context.delete(row) }
            let unique = Dictionary(dishes.map { ($0.id, $0) }, uniquingKeysWith: { _, last in last })
            for dish in unique.values {
                let row = NSEntityDescription.insertNewObject(forEntityName: "CachedDish", into: context)
                row.setValue(dish.id, forKey: "id")
                row.setValue(dish.title, forKey: "title")
                row.setValue(dish.description, forKey: "dishDescription")
                row.setValue(dish.price, forKey: "price")
                row.setValue(dish.image, forKey: "image")
                row.setValue(dish.category, forKey: "category")
            }
            try context.save()
        } catch {
            context.rollback()
            throw error
        }
    }
}

@MainActor final class MenuStore: ObservableObject {
    @Published private(set) var dishes: [FoodItem] = []
    @Published private(set) var isLoading = false
    @Published private(set) var message: String?
    @Published var search = ""
    @Published var category: FoodCategory = .all
    private let cache: MenuCache?
    init() {
        cache = try? MenuCache()
        dishes = (try? cache?.fetch()) ?? []
    }
    var filtered: [FoodItem] { Self.filter(dishes, search: search, category: category) }
    static func filter(_ dishes: [FoodItem], search: String, category: FoodCategory) -> [FoodItem] {
        dishes.filter { dish in
            (category == .all || dish.category.caseInsensitiveCompare(category.serverName) == .orderedSame) && (search.isEmpty || dish.title.range(of: search, options: [.caseInsensitive, .diacriticInsensitive]) != nil)
        }.sorted { $0.title.localizedStandardCompare($1.title) == .orderedAscending }
    }
    func load() async {
        guard !isLoading else { return }
        isLoading = true
        message = nil
        defer { isLoading = false }
        do {
            let url = URL(string: "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json")!
            var request = URLRequest(url: url)
            request.timeoutInterval = 20
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
            let fresh = try JSONDecoder().decode(MenuEnvelope.self, from: data).menu
            guard !fresh.isEmpty else { throw URLError(.cannotParseResponse) }
            if let cache {
                try cache.replace(with: fresh)
                dishes = try cache.fetch()
            } else {
                dishes = fresh
                message = "The menu is available, but offline storage could not be opened."
            }
        } catch {
            if dishes.isEmpty, let seed = Bundle.main.url(forResource: "menu", withExtension: "json"), let data = try? Data(contentsOf: seed), let offline = try? JSONDecoder().decode(MenuEnvelope.self, from: data) {
                dishes = offline.menu
            }
            message = dishes.isEmpty ? "The menu couldn’t load. Check your connection and try again." : "Showing the saved menu. Connect to the internet and tap Retry for updates."
        }
    }
}
