import SwiftUI

enum LemonTheme {
    static let green = Color(red: 73/255, green: 94/255, blue: 87/255)
    static let yellow = Color(red: 244/255, green: 206/255, blue: 20/255)
    static let ink = Color(red: 51/255, green: 51/255, blue: 51/255)
    static let mist = Color(red: 237/255, green: 239/255, blue: 238/255)
}

@main struct LittleLemonApp: App {
    @StateObject private var account = ProfileStore()
    var body: some Scene {
        WindowGroup {
            Group {
                if let profile = account.profile {
                    HomeScreen(account: account, profile: profile)
                } else {
                    OnboardingScreen(account: account)
                }
            }
            .tint(LemonTheme.green)
            .preferredColorScheme(.light)
        }
    }
}

struct LemonBrand: View {
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "leaf.fill").font(.title2).foregroundStyle(LemonTheme.green)
                .padding(8).background(LemonTheme.yellow, in: Capsule())
            Text("Little Lemon").font(.custom("Georgia-Bold", size: 24, relativeTo: .title2))
        }.accessibilityElement(children: .combine)
    }
}

struct LemonButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline).foregroundStyle(LemonTheme.ink)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(LemonTheme.yellow.opacity(configuration.isPressed ? 0.72 : 1), in: RoundedRectangle(cornerRadius: 12))
    }
}

struct PersonalFields: View {
    @Binding var draft: UserProfile
    var namesOnly = false
    var contactOnly = false
    var body: some View {
        if !contactOnly {
            TextField("First name", text: $draft.firstName).textContentType(.givenName).accessibilityIdentifier("firstName")
            TextField("Last name", text: $draft.lastName).textContentType(.familyName).accessibilityIdentifier("lastName")
        }
        if !namesOnly {
            TextField("Email", text: $draft.email).textContentType(.emailAddress).keyboardType(.emailAddress).textInputAutocapitalization(.never).autocorrectionDisabled().accessibilityIdentifier("email")
            TextField("Phone (optional)", text: $draft.phone).textContentType(.telephoneNumber).keyboardType(.phonePad).accessibilityIdentifier("phone")
        }
    }
}

struct OnboardingScreen: View {
    @ObservedObject var account: ProfileStore
    @State private var draft = UserProfile()
    @State private var step = 0
    @State private var error: String?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    LemonBrand().frame(maxWidth: .infinity).padding(.vertical, 16)
                    HStack {
                        Text("WELCOME TO THE TABLE").font(.caption.weight(.bold)).tracking(1.5)
                        Spacer()
                        Text("\(step + 1) of 3").font(.subheadline.monospacedDigit())
                    }.foregroundStyle(LemonTheme.green)
                    ProgressView(value: Double(step + 1), total: 3).accessibilityLabel("Onboarding step \(step + 1) of 3")
                    Text(["A place for you.", "Stay in touch.", "You’re on the list."][step])
                        .font(.custom("Georgia", size: 36, relativeTo: .largeTitle))
                    Text(["Start with your name. We’ll make your Little Lemon experience feel like home.", "Add your contact details for your restaurant profile. These details stay on this device.", "Check your details, then explore our Mediterranean menu."][step])
                        .font(.body).foregroundStyle(.secondary)
                    if step < 2 {
                        VStack(spacing: 16) {
                            PersonalFields(draft: $draft, namesOnly: step == 0, contactOnly: step == 1)
                        }.textFieldStyle(.roundedBorder)
                    } else {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("\(draft.firstName) \(draft.lastName)", systemImage: "person")
                            Label(draft.email, systemImage: "envelope")
                            if !draft.phone.isEmpty { Label(draft.phone, systemImage: "phone") }
                        }.frame(maxWidth: .infinity, alignment: .leading).padding(20).background(LemonTheme.mist, in: RoundedRectangle(cornerRadius: 16))
                    }
                    if let error { Text(error).foregroundStyle(.red).accessibilityIdentifier("formError") }
                    Button(step < 2 ? "Next" : "Register") { advance() }.buttonStyle(LemonButton()).accessibilityIdentifier("onboardingNext")
                    Text("A learning project. No account is created on a remote server.").font(.footnote).foregroundStyle(.secondary)
                }.padding(24)
            }
            .navigationTitle("Welcome").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if step > 0 {
                        Button { step -= 1; error = nil } label: { Label("Back", systemImage: "chevron.left") }
                    }
                }
            }
        }
    }
    private func advance() {
        error = nil
        if step == 0 && !draft.nameIsValid { error = "Enter your first and last name."; return }
        if step == 1 && !draft.emailIsValid { error = "Enter an email address such as name@example.com."; return }
        if step < 2 { step += 1; return }
        do { try account.save(draft) } catch { self.error = "Your profile couldn’t be saved. Check your details and try again." }
    }
}

struct Avatar: View {
    let initials: String
    var body: some View {
        Text(initials.isEmpty ? "LL" : initials).font(.subheadline.bold()).foregroundStyle(LemonTheme.green)
            .frame(width: 44, height: 44).background(LemonTheme.mist, in: Circle())
    }
}

struct HomeScreen: View {
    @ObservedObject var account: ProfileStore
    let profile: UserProfile
    @StateObject private var menu = MenuStore()
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 0) {
                    HStack {
                        LemonBrand()
                        Spacer()
                        NavigationLink { ProfileScreen(account: account, initial: profile) } label: { Avatar(initials: profile.initials) }
                            .accessibilityLabel("Open profile").accessibilityIdentifier("openProfile")
                    }.padding(.horizontal, 20).padding(.vertical, 16)
                    hero
                    VStack(alignment: .leading, spacing: 16) {
                        Text("ORDER FOR DELIVERY").font(.headline).tracking(0.8).padding(.top, 24)
                        ScrollView(.horizontal, showsIndicators: true) {
                            HStack(spacing: 10) {
                                ForEach(FoodCategory.allCases) { category in
                                    Button { menu.category = category } label: {
                                        Text(category.rawValue).font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 11)
                                            .foregroundStyle(menu.category == category ? Color.white : LemonTheme.green)
                                            .background(menu.category == category ? LemonTheme.green : LemonTheme.mist, in: Capsule())
                                    }.accessibilityAddTraits(menu.category == category ? .isSelected : [])
                                        .accessibilityIdentifier("category-\(category.serverName)")
                                }
                            }.padding(.bottom, 6)
                        }
                        if let message = menu.message {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(message).font(.footnote)
                                Button("Retry") { Task { await menu.load() } }.disabled(menu.isLoading)
                            }.padding(12).frame(maxWidth: .infinity, alignment: .leading).background(LemonTheme.mist, in: RoundedRectangle(cornerRadius: 10))
                        }
                        if menu.isLoading && menu.dishes.isEmpty { ProgressView("Loading menu…").frame(maxWidth: .infinity, minHeight: 100) }
                        if !menu.isLoading && menu.filtered.isEmpty {
                            VStack(spacing: 10) {
                                Image(systemName: "magnifyingglass").font(.title)
                                Text("No dishes found").font(.headline)
                                Text("Try another search or choose All.").font(.subheadline).foregroundStyle(.secondary)
                                Button("Clear filters") { menu.search = ""; menu.category = .all }
                            }.frame(maxWidth: .infinity, minHeight: 160)
                        }
                        LazyVStack(spacing: 0) {
                            ForEach(menu.filtered) { dish in
                                NavigationLink { DishDetail(dish: dish) } label: { DishRow(dish: dish) }.buttonStyle(.plain)
                                Divider()
                            }
                        }
                    }.padding(.horizontal, 20).padding(.bottom, 24)
                }
            }
            .navigationBarHidden(true)
            .task { await menu.load() }
            .refreshable { await menu.load() }
        }
    }
    private var hero: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Little Lemon").font(.custom("Georgia", size: 36, relativeTo: .largeTitle)).foregroundStyle(LemonTheme.yellow)
                    Text("Chicago").font(.title2).foregroundStyle(.white)
                    Text("We are a family-owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.")
                        .font(.body).foregroundStyle(.white).padding(.top, 8)
                }
                Image(systemName: "fork.knife.circle.fill").font(.system(size: 68)).foregroundStyle(LemonTheme.yellow).accessibilityHidden(true).padding(.top, 10)
            }
            HStack {
                Image(systemName: "magnifyingglass").foregroundStyle(LemonTheme.green)
                TextField("Search dishes", text: $menu.search).autocorrectionDisabled().textInputAutocapitalization(.never).accessibilityIdentifier("menuSearch")
                if !menu.search.isEmpty {
                    Button { menu.search = "" } label: { Image(systemName: "xmark.circle.fill") }.accessibilityLabel("Clear search")
                }
            }.padding(14).background(.white, in: RoundedRectangle(cornerRadius: 12))
        }.padding(20).background(LemonTheme.green)
    }
}

struct FoodPhoto: View {
    let url: String
    var body: some View {
        AsyncImage(url: URL(string: url)) { phase in
            if let image = phase.image { image.resizable().scaledToFill() }
            else { ZStack { LemonTheme.mist; Image(systemName: "fork.knife").foregroundStyle(LemonTheme.green) } }
        }.frame(width: 88, height: 88).clipped().clipShape(RoundedRectangle(cornerRadius: 12)).accessibilityHidden(true)
    }
}

struct DishRow: View {
    let dish: FoodItem
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 7) {
                Text(dish.title).font(.headline).foregroundStyle(LemonTheme.ink)
                Text(dish.description).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                Text(dish.numericPrice, format: .currency(code: "USD")).font(.subheadline.bold()).foregroundStyle(LemonTheme.green)
            }.frame(maxWidth: .infinity, alignment: .leading)
            FoodPhoto(url: dish.image)
        }.padding(.vertical, 18).contentShape(Rectangle())
    }
}

struct DishDetail: View {
    let dish: FoodItem
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                FoodPhoto(url: dish.image)
                Text(dish.title).font(.largeTitle.bold())
                Text(dish.description)
                Text(dish.numericPrice, format: .currency(code: "USD")).font(.title2.bold()).foregroundStyle(LemonTheme.green)
                Label(dish.category.capitalized, systemImage: "tag")
            }.padding(24).frame(maxWidth: .infinity, alignment: .leading)
        }.navigationTitle("Dish details").navigationBarTitleDisplayMode(.inline).toolbar(.visible, for: .navigationBar)
    }
}

struct ProfileScreen: View {
    @ObservedObject var account: ProfileStore
    @State private var draft: UserProfile
    @State private var error: String?
    @State private var saved = false
    @State private var showLogOut = false
    @Environment(\.dismiss) private var dismiss
    init(account: ProfileStore, initial: UserProfile) {
        self.account = account
        _draft = State(initialValue: initial)
    }
    var body: some View {
        Form {
            Section {
                HStack(spacing: 16) { Avatar(initials: draft.initials); Text("Personal information").font(.headline) }.padding(.vertical, 8)
                PersonalFields(draft: $draft)
            } footer: { Text("Your details are stored only on this device.") }
            if let error { Section { Text(error).foregroundStyle(.red) } }
            Section {
                Button("Save changes") {
                    error = draft.validationError
                    guard error == nil else { return }
                    do { try account.save(draft); saved = true } catch { self.error = "Your changes couldn’t be saved. Try again." }
                }.buttonStyle(LemonButton()).listRowBackground(Color.clear).accessibilityIdentifier("saveProfile")
                Button("Discard changes") { dismiss() }.frame(maxWidth: .infinity).accessibilityIdentifier("discardProfile")
            }
            Section {
                Button("Log out", role: .destructive) { showLogOut = true }.accessibilityIdentifier("logOut")
            } footer: { Text("Logging out removes your saved personal details and returns to the first onboarding page.") }
        }
        .navigationTitle("Profile").navigationBarTitleDisplayMode(.inline).toolbar(.visible, for: .navigationBar)
        .alert("Profile saved", isPresented: $saved) { Button("OK", role: .cancel) {} } message: { Text("Your changes will still be here when you reopen the app.") }
        .confirmationDialog("Remove your personal details from this device?", isPresented: $showLogOut, titleVisibility: .visible) {
            Button("Log out", role: .destructive) { account.logOut() }
            Button("Cancel", role: .cancel) {}
        }
    }
}
