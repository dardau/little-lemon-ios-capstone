# Little Lemon behavior contract

Source: live Coursera grading criteria, captured in
`../nov8-handoff/project-instructions.txt`. Visual contract: DESIGN.md.
This local learning app does not place orders, collect payments, authenticate
with a server or transmit profile fields.

| Capability | Canonical owner | Source of truth | Allowed variants | Verification |
|---|---|---|---|---|
| Form | PersonalFields + UserProfile.validationError | AppData.swift | onboarding / profile | CapstoneTests + simulator |
| Toast | SwiftUI alert on ProfileScreen | LittleLemonApp.swift | saved / inline error | simulator |
| CRUD | ProfileStore | AppData.swift | register / save / discard / log out | CapstoneTests |
| Navigation | NavigationStack | LittleLemonApp.swift | steps / Home→Profile / Home→Dish | simulator |
| Search | MenuStore.filter + hero TextField | AppData.swift | local text / category | CapstoneTests |
| Scrollbar | Native ScrollView/Form | platform | vertical content / horizontal categories | simulator |

Three onboarding pages have Next, Back, and Register on the summary. Registration
requires names and valid email. Errors preserve input. Profile opens populated;
Save persists locally; Back/Discard leaves changes unsaved. Logout confirms,
removes the stored profile key and returns to empty onboarding.

Menu refresh has one in-flight request and a 20-second timeout. Errors preserve
cache and expose Retry. Bundled course-menu fallback is explicitly labeled saved.
Core Data replaces data transactionally with unique IDs and rolls back failures.

Local search is case/diacritic insensitive and clears immediately; no remote
debounce/stale race applies. Categories persist until changed. Empty results offer
Clear filters. Native SwiftUI owns focus, keyboard, safe areas and Back affordances.
No web-only table, date-picker or scrollbar CSS contract applies.
