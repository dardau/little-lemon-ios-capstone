---
version: alpha
colors:
  primary: "#495E57"
  accent: "#F4CE14"
  text: "#333333"
  surface: "#FFFFFF"
  muted: "#EDEFEE"
typography:
  display:
    fontFamily: "Georgia, serif"
  body:
    fontFamily: "-apple-system, sans-serif"
rounded:
  control: "12px"
  panel: "16px"
spacing:
  inset: "20px"
  form: "24px"
components:
  primaryButton:
    backgroundColor: "#F4CE14"
    textColor: "#333333"
---

## Overview

Native iPhone learning app for Little Lemon guests: collect a local profile and
browse a Mediterranean menu. Preserve the course's green/yellow identity. The
signature is the yellow Georgia restaurant name on the green hero. Other controls
stay familiar. Avoid gradients, dashboard cards and decorative metrics.

## Colors

Runtime `LemonTheme` in `LittleLemon/LittleLemonApp.swift` is canonical (Model B).
`primary` maps to `green`, `accent` to `yellow`, `text` to `ink`, and `muted` to
`mist`. All screens consume that enum. Errors and destructive actions use native
semantic colors/roles. White is the main surface.

## Typography

Georgia supplies display character; Dynamic Type system text handles forms,
body, prices and controls. English and USD match the course. Unicode names work.

## Layout

Phone-first natural scrolling. Home has header → hero with search → category bar
→ food rows, matching `wireframe-home.jpg`. Rows reserve 88×88 image geometry.
Native navigation owns safe areas and Back. Body text wraps at large sizes.

## Elevation & Depth

Flat surfaces, separators and native modal sheets; no card shadows.

## Shapes

12-point controls/images, 16-point summary panel, pill category buttons. Primary
action height is 50 points; the profile control is 44×44.

## Components

Shared owners: LemonBrand, LemonButton, PersonalFields, Avatar, FoodPhoto, DishRow.
Runtime radii/spacing correspond to the numeric tokens above. No CSS adapter is
present. SwiftUI controls own keyboard, focus, scrolling and modal semantics.

## Do's and Don'ts

Keep profile data on device. Preserve invalid form input and show a correction.
Indicate selected categories semantically. Supply Clear search and Clear filters.
Never describe an offline menu as a successful live download.
